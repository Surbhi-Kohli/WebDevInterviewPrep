const api="https://api.github.com/users/akshaymarch7";
const promise=fetch(api);
debugger
console.log(promise)
debugger
promise.then(res=>console.log(res));