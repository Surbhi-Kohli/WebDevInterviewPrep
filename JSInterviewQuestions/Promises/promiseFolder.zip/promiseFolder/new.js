for(let i = 1; i < 6; i++) {
    debugger
    setTimeout(()=>{
       console.log(i);
    },1000);
 }
 function outer(input)
 {
     return function inner()
     {

     console.log(input)
     }
 }
 let ans=outer("helloClosure");
 debugger
 ans()